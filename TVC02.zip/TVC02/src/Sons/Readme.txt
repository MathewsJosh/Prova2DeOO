Pegar os sons da classe do trabalho
